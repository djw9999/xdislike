document.addEventListener('DOMContentLoaded', () => {
  restoreState();
  wireMiniWindowButtons();
  wireSettings();
});

const VERIFY_ENDPOINT = 'https://api.polar.sh/v1/users/benefit/verify'; // Placeholder, actual endpoint might differ based on integration type
// Note: For client-side key verification without a backend proxy, you often just validatethe format or use a specific public endpoint if available. 
// However, securely, you should recommend the user validates this server-side.
// For this MVP/Client-side demo, we will simulate verification OR use a simple check.


  document.getElementById('activate-btn').addEventListener('click', async () => {
    const key = document.getElementById('license-key').value.trim();
    const btn = document.getElementById('activate-btn');

  if (!key) {
    alert('Please enter a license key');
    return;
  }

  btn.innerText = 'Verifying...';
  btn.disabled = true;

  try {
    // Real Verification
    const response = await fetch('https://api.polar.sh/v1/customer-portal/license-keys/validate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        key: key,
        organization_id: 'bf5e3e6c-d148-45fc-b3e0-c5594d693edb'
      })
    });

    if (!response.ok) {
        throw new Error('Network error or invalid request');
    }

    const data = await response.json();

    if (data.status === 'granted') {
      await chrome.storage.local.set({ licenseKey: key, isPro: true });
      updateUI(true);
      alert('Activation Successful!');
    } else {
      alert('Invalid License Key or Expired');
    }
  } catch (error) {
    console.error(error);
    alert('Error verifying key. Please check your internet connection.');
  } finally {
    btn.innerText = 'Activate License';
    btn.disabled = false;
  }
});

function restoreState() {
  chrome.storage.local.get(['isPro', 'mergeCommunityTabs', 'blockAds'], (result) => {
    updateUI(result.isPro);
    const mergeEl = document.getElementById('merge-community-tabs');
    if (mergeEl) mergeEl.checked = !!result.mergeCommunityTabs;
    const blockAdsEl = document.getElementById('block-ads');
    if (blockAdsEl) blockAdsEl.checked = !!result.blockAds;
  });
}

function updateUI(isPro) {
  const form = document.getElementById('activation-form');
  const features = document.getElementById('main-features');
  const status = document.getElementById('license-status');
  
  if (isPro) {
    if (form) form.style.display = 'none';
    if (features) features.style.display = 'grid';
    if (status) {
      status.innerText = 'PRO';
      status.classList.remove('locked');
    }
  } else {
    if (form) form.style.display = 'grid';
    if (features) features.style.display = 'none';
    if (status) {
      status.innerText = 'LOCKED';
      status.classList.add('locked');
    }
  }
}

function wireSettings() {
  const mergeEl = document.getElementById('merge-community-tabs');
  const blockAdsEl = document.getElementById('block-ads');

  if (mergeEl) {
    mergeEl.addEventListener('change', async () => {
      await chrome.storage.local.set({ mergeCommunityTabs: !!mergeEl.checked });
    });
  }

  if (blockAdsEl) {
    blockAdsEl.addEventListener('change', async () => {
      await chrome.storage.local.set({ blockAds: !!blockAdsEl.checked });
    });
  }
}

const MINI_WINDOW_ID_KEY = 'miniWindowId';

function wireMiniWindowButtons() {
  const openBtn = document.getElementById('open-mini-btn');
  const closeBtn = document.getElementById('close-mini-btn');

  if (openBtn) openBtn.addEventListener('click', openOrFocusMiniWindow);
  if (closeBtn) closeBtn.addEventListener('click', closeMiniWindow);

  const cleanBtn = document.getElementById('open-cleaner-btn');
  if (cleanBtn) {
    cleanBtn.addEventListener('click', () => {
      console.log('Cleaner btn clicked');
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].id) {
          console.log('Sending message to tab:', tabs[0].id);
          chrome.tabs.sendMessage(tabs[0].id, { action: 'TOGGLE_CLEANER_MODE' }, (response) => {
             if (chrome.runtime.lastError) {
                 console.error('Message failed:', chrome.runtime.lastError);
             } else {
                 console.log('Message sent, response:', response);
             }
          });
        } else {
             console.error('No active tab found');
        }
      });
    });
  }
}

function openOrFocusMiniWindow() {
  chrome.storage.local.get([MINI_WINDOW_ID_KEY], (result) => {
    const existingId = result && result[MINI_WINDOW_ID_KEY];

    if (typeof existingId === 'number') {
      chrome.windows.get(existingId, (win) => {
        if (!chrome.runtime.lastError && win) {
          chrome.windows.update(existingId, { focused: true }, () => {});
          return;
        }

        chrome.storage.local.remove([MINI_WINDOW_ID_KEY], () => {
          createMiniWindow();
        });
      });
      return;
    }

    createMiniWindow();
  });
}

function createMiniWindow() {
  chrome.windows.create(
    {
      url: 'https://x.com/home',
      type: 'popup',
      width: 420,
      height: 800,
      focused: true
    },
    (win) => {
      if (chrome.runtime.lastError || !win || typeof win.id !== 'number') return;

      chrome.storage.local.set({ [MINI_WINDOW_ID_KEY]: win.id }, () => {
      });
    }
  );
}

function closeMiniWindow() {
  chrome.storage.local.get([MINI_WINDOW_ID_KEY], (result) => {
    const id = result && result[MINI_WINDOW_ID_KEY];
    if (typeof id !== 'number') {
      return;
    }

    chrome.windows.remove(id, () => {
      chrome.storage.local.remove([MINI_WINDOW_ID_KEY], () => {
      });
    });
  });
}
