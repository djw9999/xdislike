const MINI_WINDOW_ID_KEY = 'miniWindowId';

function closeMiniWindow() {
  chrome.storage.local.get([MINI_WINDOW_ID_KEY], (result) => {
    const id = result && result[MINI_WINDOW_ID_KEY];
    if (typeof id !== 'number') return;

    chrome.windows.remove(id, () => {
      chrome.storage.local.remove([MINI_WINDOW_ID_KEY], () => {});
    });
  });
}

chrome.commands.onCommand.addListener((command) => {
  if (command === 'close-mini-window') {
    closeMiniWindow();
  }
});

chrome.windows.onRemoved.addListener((windowId) => {
  chrome.storage.local.get([MINI_WINDOW_ID_KEY], (result) => {
    const id = result && result[MINI_WINDOW_ID_KEY];
    if (id === windowId) {
      chrome.storage.local.remove([MINI_WINDOW_ID_KEY], () => {});
    }
  });
});

// ---------------------------------------------------------
// TOKEN SNIFFER (For X API Access)
// ---------------------------------------------------------
let xAuth = {};

chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    let hasUpdates = false;
    for (const header of details.requestHeaders) {
      const name = header.name.toLowerCase();
      if (name === 'authorization') {
        if (xAuth.bearer !== header.value) {
           xAuth.bearer = header.value;
           hasUpdates = true;
        }
      } else if (name === 'x-csrf-token') {
        if (xAuth.csrf !== header.value) {
            xAuth.csrf = header.value;
            hasUpdates = true;
        }
      } else if (name === 'x-guest-token') {
         if (xAuth.guest !== header.value) {
             xAuth.guest = header.value;
             hasUpdates = true;
         }
      } else if (name === 'cookie') {
          if (xAuth.cookie !== header.value) {
              xAuth.cookie = header.value;
              hasUpdates = true;
          }
      }
    }

    if (hasUpdates) {
       chrome.storage.local.set({ xAuthTokens: xAuth });
    }
  },
  { urls: ["https://x.com/*", "https://twitter.com/*"] },
  ["requestHeaders"]
);


