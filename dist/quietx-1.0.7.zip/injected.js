(function() {
    const originalFetch = window.fetch;
    const originalOpen = XMLHttpRequest.prototype.open;

    window.fetch = async function(resource, options) {
        
        // Sniff Following
        if (typeof resource === 'string' && (resource.includes('/Following') || resource.includes('Following'))) {
            try {
                 window.postMessage({
                    type: 'QX_SNIFF_FOLLOWING',
                    url: resource,
                    body: options ? options.body : null,
                    method: options ? options.method : 'GET'
                 }, '*');
            } catch(e) {}
        }
        
        // Sniff Unfollow (Destroy)
        if (typeof resource === 'string' && (resource.includes('destroy.json') || resource.includes('Unfollow'))) {
             try {
                 window.postMessage({
                    type: 'QX_SNIFF_UNFOLLOW',
                    url: resource,
                    body: options ? options.body : null,
                    method: options ? options.method : 'POST'
                 }, '*');
             } catch(e) {}
        }

        return originalFetch.apply(this, arguments);
    };

    // Also watch XHR just in case
    XMLHttpRequest.prototype.open = function(method, url) {
        if (typeof url === 'string') {
             if (url.includes('/Following') || url.includes('Following')) {
                 this.addEventListener('load', function() {
                      window.postMessage({
                         type: 'QX_SNIFF_FOLLOWING',
                         url: url,
                         method: method
                      }, '*');
                 });
             }
        }
        return originalOpen.apply(this, arguments);
    };

})();
